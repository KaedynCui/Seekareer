function turn_h() {
    if ("" != document.getElementById("skill").value || "#" != document.getElementById("skill").value) {
        document.getElementById("tag").innerHTML = document.getElementById("tag").innerHTML + " " + document.getElementById("skill").value;
        document.getElementById("tag").style.color = "blue";
    }
}

function save() {
    document.getElementById("save").innerHTML = "Edit";
}

function send() {
    alert("Your CV has been sent to 3 company(ies)!");
}